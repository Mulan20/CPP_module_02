/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/22 17:37:06 by nkham             #+#    #+#             */
/*   Updated: 2026/07/22 17:37:07 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.hpp"

Fixed::Fixed() : _fixedPointValue(0)
{
    std::cout << "Default constructor is called!" << std::endl;

}

Fixed::Fixed(const Fixed &other)
{
    std::cout << "Copy Constructor is called!" << std::endl;
    *this = other;
}

Fixed &Fixed::operator=(const Fixed &other)
{
    std::cout << "Copy assignment operator is called!" << std::endl;
    setRawBits(other.getRawBits());
    return (*this);
}

Fixed::~Fixed()
{
    std::cout <<"Destructor is called!" << std::endl;
}

int Fixed:: getRawBits(void) const
{
    return _fixedPointValue;
}

void Fixed:: setRawBits(int const raw)
{
    _fixedPointValue = raw;
}
