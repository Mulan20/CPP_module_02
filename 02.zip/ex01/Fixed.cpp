/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/22 17:37:32 by nkham             #+#    #+#             */
/*   Updated: 2026/07/22 17:37:34 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.hpp"

Fixed::Fixed() : _fixedPointValue(0)
{
    std::cout << "Default constructor is called!" << std::endl;

}

Fixed::Fixed(const int number)
{
	_fixedPointValue = number << _fractionalBits;
	std::cout << "Int constructor called\n";
}

Fixed::Fixed(const float number)
{

	_fixedPointValue = roundf(number * (1 << _fractionalBits));
	std::cout << "Float constructor called" << std::endl;
}

Fixed::Fixed(const Fixed &other)
{
    std::cout << "Copy Constructor is called!" << std::endl;
    *this = other;
}

Fixed &Fixed::operator=(const Fixed &other)
{
    std::cout << "Copy assignment operator is called!" << std::endl;
    setRawBits(other.getRawBits());
    return (*this);
}

Fixed::~Fixed()
{
    std::cout <<"Destructor is called!" << std::endl;
}

float Fixed::toFloat(void) const
{
	return (static_cast<float>(_fixedPointValue) / (1 << _fractionalBits));
}

int Fixed::toInt(void) const
{
	return (_fixedPointValue >> _fractionalBits);
}

int Fixed:: getRawBits(void) const
{
    return _fixedPointValue;
}

void Fixed:: setRawBits(int const raw)
{
    _fixedPointValue = raw;
}

std::ostream &operator<<(std::ostream &os, Fixed const &fixed)
{
    os << fixed.toFloat();
    return os;
}
