/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/22 17:37:42 by nkham             #+#    #+#             */
/*   Updated: 2026/07/22 17:37:43 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FIXED_HPP
#define FIXED_HPP
#include <iostream>
#include <cmath>

class Fixed
{
	private:
		int	_fixedPointValue;
		static const int	_fractionalBits = 8;
	
	public:
		Fixed();
        Fixed(const int num);
        Fixed(const float num);
		Fixed(const Fixed &other);
		Fixed &operator=(const Fixed &other);
		~Fixed();

        float toFloat(void) const;
        int toInt(void) const;
		int	getRawBits(void) const;
		void	setRawBits(int const raw);
};

std::ostream &operator<<(std::ostream &os, Fixed const &fixed);

#endif
